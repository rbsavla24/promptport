# Prompt Export (Chrome extension)

**v3.0.0 — UI 2.0:** greyscale, Verdana, hand-drawn panel with no product name or logo, equal side-by-side download buttons, sticky actions, site-neutral wording everywhere in the UI, and author links (LinkedIn · GitHub · Figma) that appear after a download, import, undo, backup or Replace all finishes and hide when the next one starts.

**v3.2.4 — line breaks on import (both sites):** a line break you type in a .md file now stays a line break (before, two lines like “**Q:** …” and “**A:** …” were joined into one). Exports still re-import as “Nothing to change”.

**v3.2.3 — safety fix (Ringg):** the background data reader now only ever repeats a page *read* (GET). Before, if the assistant data had last come from a save, it could re-send that save without its content when you exported after a lot of page activity. It also keeps the latest assistant data so names stay correct.

**v3.2.2 — live-tested on both sites:** exported files no longer contain whitespace-only lines inside list items.

**v3.2.1:** on Rezolv, lines separated by a single line break (common in Ringg prompts) now arrive as separate paragraphs instead of running together (that editor has no line breaks), and re-importing the same file there reports "Nothing to change". The last import can be undone from the Import tab even after you leave its results screen.

Exports a Ringg.ai assistant's five configuration sections as a single ZIP
containing five markdown files:

- `first-message.md` — First Message
- `objective.md` — Objective
- `response-guideline.md` — Response Guideline
- `conversation-script.md` — Conversation Script
- `faqs.md` — FAQs

## Install (Load unpacked)

1. Unzip this folder somewhere permanent (e.g. `Documents/ringg-md-exporter`).
2. Open Chrome → `chrome://extensions`.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the unzipped `ringg-md-exporter` folder.
5. Pin the extension (puzzle-piece icon → pin) so its icon is visible.

## Use

1. Open your assistant page on ringg.ai, e.g.
   `https://www.ringg.ai/dashboard/assistants/<id>?orchestration=single`
2. **Reload the page once** after installing (so the extension can capture the
   data as the page loads).
3. Either:
   - Click the extension icon in the toolbar → review the preview → **Download ZIP**, or
   - Click the floating **⬇ Export MD** button at the bottom-right of the page.
4. The ZIP saves to your Downloads folder, named after the assistant.

## Import (write a ZIP back into Ringg)

Open the on-page panel (**⬇ Export MD** button) and click **⬆ Import a ZIP
(overwrite buckets)**. Pick a ZIP containing the same five files
(`First message.md`, `Objective.md`, `Response Guidelines.md`,
`Conversation Script.md`, `FAQs.md`). The extension:

1. Reads the ZIP (works with the exporter's ZIPs and with Finder-recompressed
   ones), and matches each file to its bucket by name.
2. Shows a preview of exactly which buckets it will **overwrite** — confirm to
   proceed.
3. Expands any collapsed buckets, converts each file's Markdown back to HTML,
   and pastes it into the matching editor (reconstructing headings, tables and
   `{{variable}}` mention chips).

After importing, review each bucket on the page and click Ringg's **Save** if it
doesn't autosave. Any bucket that couldn't be written is marked ✕ in the results.

## Find & replace across the 5 buckets

In the on-page panel, click **🔎 Find & replace**. Type a term and **Find /
count** — matches are highlighted in yellow on the page and counted per bucket
(with Match case / Whole word options). **Replace all** rewrites every matching
bucket via the same copy→paste round-trip used by import. Keep a backup export
first; review and Save afterwards.

## Diff before import

When you **Import a ZIP**, before anything is overwritten the panel shows a
per-bucket diff (`+added −removed` lines, with a "view changes" toggle) between
the current bucket content and the incoming file, so you can confirm exactly
what will change. Very large sections show counts only.

## How it extracts the fields

It uses two strategies and picks whichever finds content (API preferred):

1. **API capture** — it watches the assistant data Ringg's own page loads from
   its API and reads the five fields straight from that JSON.
2. **On-page fallback** — if a field isn't in the captured data, it reads the
   value from the page by matching the section's visible label.

The preview panel shows, per section, whether content was found, the source
(`api` or `dom`), and the character count — so you can confirm before saving.

## If a section shows empty

- Make sure you reloaded the assistant page after installing.
- Open the section in the Ringg UI at least once (some editors only render
  their content when the tab/section is opened), then click **Refresh**.
- If it's still empty, the field's label or API key on your account may differ
  from the defaults. Send me the console output from the snippet below and I'll
  tune the matching.

### Diagnostic snippet (optional)

On the assistant page, open DevTools (F12) → Console, paste this, and share
the output:

```js
copy(JSON.stringify(
  Array.from(document.querySelectorAll('label,h1,h2,h3,h4,textarea,[contenteditable=true],.ql-editor'))
    .slice(0,200)
    .map(e => ({tag:e.tagName, cls:e.className, text:(e.innerText||e.value||'').slice(0,60)})),
  null, 2));
console.log('Copied element map to clipboard.');
```

## Files

- `manifest.json` — MV3 config
- `interceptor.js` — captures assistant JSON from Ringg's API (page world)
- `extract.js` — maps captured data / DOM into the 5 sections
- `zip.js` — dependency-free ZIP writer
- `content.js` — floating button, preview panel, download
- `popup.html` / `popup.js` — toolbar popup
